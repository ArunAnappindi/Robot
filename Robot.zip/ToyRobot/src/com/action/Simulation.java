package com.action;


import com.idealo.test.domainobjects.Board;
import com.idealo.test.domainobjects.Position;
import com.idealo.test.domainobjects.Robot;
import com.idealo.test.domainobjects.Position.Direction;

public class Simulation {

	Board board;
    Robot robot;

    public Simulation(Board board, Robot robot) {
        this.board = board;
        this.robot = robot;
    }

    /**
     * Places the robot on the squareBoard  in position X,Y and facing NORTH, SOUTH, EAST or WEST
     *
     * @param position Robot position
     * @return true if placed successfully
     * @throws ToyRobotException
     */
    public boolean placeRobot(Position position) throws Exception {

        if (board == null)
            throw new Exception("Invalid squareBoard object");

        if (position == null)
            throw new Exception("Invalid position object");

        if (position.getDirection() == null)
            throw new Exception("Invalid direction value");

        // validate the position
        if (!board.isValidPosition(position))
            return false;

        // if position is valid then assign values to fields
        robot.setPosition(position);
        return true;
    }

    /**
     * checks the steps provided and executes necessary steps
     * 
     * @param inputString
     * @return
     * @throws Exception
     */
    public String checkAndExecute(String inputString) throws Exception {
        String[] args = inputString.split(" ");

        // validate command
        String command;
        try {
            command = args[0];
        } catch (IllegalArgumentException e) {
            throw new Exception("Invalid command");
        }
        if (command.equals("PLACE") && args.length < 2) {
            throw new Exception("Invalid command");
        }

        // validate PLACE params
        String[] params;
        int x = 0;
        int y = 0;
        Position.Direction commandDirection = null;
        if (command.equals("PLACE")) {
            params = args[1].split(",");
            try {
                x = Integer.parseInt(params[0]);
                y = Integer.parseInt(params[1]);
                commandDirection = Position.Direction.valueOf(params[2]);
            } catch (Exception e) {
                throw new Exception("Invalid command");
            }
        }

        String output;

        switch (command) {
            case "PLACE":
                output = String.valueOf(placeRobot(new Position(x, y, commandDirection)));
                break;
            case "MOVE":
                Position newPosition = robot.getPosition().getNextPosition();
                if (!board.isValidPosition(newPosition))
                    output = String.valueOf(false);
                else
                    output = String.valueOf(robot.move(newPosition));
                break;
            case "LEFT":
                output = String.valueOf(robot.rotateLeft());
                break;
            case "RIGHT":
                output = String.valueOf(robot.rotateRight());
                break;
            case "REPORT":
                output = report();
                break;
            default:
                throw new Exception("Invalid command");
        }

        return output;
    }

    /**
     * Returns the X,Y and Direction of the robot
     */
    public String report() {
        if (robot.getPosition() == null)
            return null;

        return robot.getPosition().getX() + "," + robot.getPosition().getY() + "," + robot.getPosition().getDirection().toString();
    }
}
