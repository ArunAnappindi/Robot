package com.action;



import java.util.Scanner;

import com.idealo.test.domainobjects.Board;
import com.idealo.test.domainobjects.Robot;

public class Start {

    public static void main(String[] args) {

        Board squareBoard = new Board(5, 5);
        Robot robot = new Robot();
        Simulation startSim = new Simulation(squareBoard, robot);

        System.out.println("Robot Application");
        System.out.println("Please enter a command, Valid commands are:");
        System.out.println("\'PLACE X,Y,NORTH|SOUTH|EAST|WEST\', MOVE, LEFT, RIGHT, REPORT or EXIT");

        boolean keepRunning = true;
        Scanner inputScanner = new Scanner(System.in);
        while (keepRunning) {
        	try {
        	String inputString = inputScanner.nextLine();
            if ("EXIT".equals(inputString)) {
                keepRunning = false;
                break;
            } else {
                    String outputVal = startSim.checkAndExecute(inputString);
                    System.out.println(outputVal);
            	}
        	} catch(Exception e) {
        		System.out.println(e.getMessage());
        	} 
        }
        inputScanner.close();
    }
}